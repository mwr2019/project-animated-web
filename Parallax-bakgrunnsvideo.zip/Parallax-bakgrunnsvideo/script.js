npm i stickybits --save-dev

stickybits('[your-sticky-selector]');
